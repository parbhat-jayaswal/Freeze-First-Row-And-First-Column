//
//  ViewController.swift
//  StickyRowCol_Web
//
//  Created by Parbhat on 19/01/23.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    
    @IBOutlet weak var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupWebView()
    }
    
    fileprivate func setupWebView() {
        webView.scrollView.panGestureRecognizer.isEnabled = false
        webView.scrollView.bounces = false
        

        do {
            guard let filePath = Bundle.main.path(forResource: "index", ofType: "html")
            else {
                // File Error
                print ("File reading error")
                return
            }
            
            let contents =  try String(contentsOfFile: filePath, encoding: .utf8)
            let baseUrl = URL(fileURLWithPath: filePath)
            webView.loadHTMLString(contents as String, baseURL: baseUrl)
        }
        catch {
            print ("File HTML error")
        }
        
        webView.layer.borderWidth = 1
        webView.layer.borderColor = UIColor.gray.cgColor
        webView.layer.cornerRadius = 5
    }
    
    
    
}




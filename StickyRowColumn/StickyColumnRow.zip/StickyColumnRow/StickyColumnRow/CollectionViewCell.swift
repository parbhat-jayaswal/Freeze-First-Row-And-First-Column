//
//  CollectionViewCell.swift
//  StickyColumnRow
//
//  Created by Admin on 28/12/22.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    static let reuseID = "CollectionViewCell"

    @IBOutlet weak var titleLabel: UILabel!

}
